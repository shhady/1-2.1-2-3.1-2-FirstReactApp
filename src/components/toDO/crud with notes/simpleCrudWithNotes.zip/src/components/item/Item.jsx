import React, { Component } from 'react';

export default class Item extends Component {
  //? controlled state ↓
  state = { title: '' };
  handleOnChange = ({ target }) => {
    this.setState({ title: target.value });
  };
  render() {
    return (
      <div className='item'>
        <input onChange={this.handleOnChange} value={this.state.title} />

        <button
          onClick={() =>
            this.props.handleUpdate(this.props.id, this.state.title)
          }
        >
          Update
        </button>

        <button
          onClick={() => {
            this.props.handleDelete(this.props.id);
          }}
        >
          Delete
        </button>
        <p>{this.props.title}</p>
      </div>
    );
  }
}
