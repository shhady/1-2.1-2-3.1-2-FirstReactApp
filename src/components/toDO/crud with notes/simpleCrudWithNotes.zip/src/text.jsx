import React from 'react';
const data = [
  { todo: 'something', id: 1 },
  { todo: 'something', id: 2 },
];

//? Read - take the data save it to state, show the state on the screen
//? Delete - on todoDelete item click delete item from the state
//? Create - Add a item to the state (todo + id)

function text() {
  return <div>text</div>;
}

export default text;
