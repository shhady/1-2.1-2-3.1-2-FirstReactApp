import { Component } from 'react';
import Item from './components/item/Item';
import { data } from './constants/fakeDate';

//* CRUD
//? Create V
//? Read V
//? Update
//? Delete V

export default class App extends Component {
  state = { arrOfObj: [], itemTitleValue: '' };

  //! CREATE
  handleCreate = () => {
    const newItem = {
      title: this.state.itemTitleValue,
      id: Math.random(),
    };
    // console.log(newItem);
    this.setState((prev) => {
      return { arrOfObj: [...prev.arrOfObj, newItem] }; //* ← That one is better!
      // prev.arrOfObj.push(newItem);
      // return { arrOfObj: prev.arrOfObj };
    });
  };

  //! READ
  componentDidMount() {
    this.setState({ arrOfObj: data }, () => {
      // console.log(this.state.arrOfObj);
    });
  }

  // //! UPDATE
  handleUpdate = (id, newTitle) => {
    const newArrOfObj = this.state.arrOfObj.map((obj) => {
      if (obj.id === id) {
        return { ...obj, title: newTitle };
      }
      return obj;
    });
    console.log(newArrOfObj);
    this.setState({ arrOfObj: newArrOfObj });
    // this.setState((prevState) => {
    //   //* ← That one is better!
    //   const arrOfObjAfterDelete = prevState.arrOfObj.map((obj) => {
    //     if (obj.id === id) {
    //       return { id, title };
    //     } else {
    //       return obj;
    //     }
    //   });
    //   return { arrOfObj: arrOfObjAfterDelete };
    // });
  };

  //! DELETE
  handleDelete = (id) => {
    const arrOfObjAfterDelete = this.state.arrOfObj.filter((obj) => {
      return obj.id !== id;
    });
    this.setState({ arrOfObj: arrOfObjAfterDelete });
    // this.setState((prevState) => {  //* ← That one is better!
    //   const arrOfObjAfterDelete = prevState.arrOfObj.filter(
    //     (obj) => obj.id !== id
    //   );
    //   return { arrOfObj: arrOfObjAfterDelete };
    // });
  };

  //? Controlled add item input
  handleOnChange = (event) => {
    // console.log(event);
    // console.dir(event.target);
    // console.log(event.target.value);
    this.setState({ itemTitleValue: event.target.value });
  };

  //? Painting data on the screen by calling Item component
  insertData = () => {
    return this.state.arrOfObj.map((obj) => (
      <Item
        handleUpdate={this.handleUpdate}
        handleDelete={this.handleDelete}
        key={obj.id}
        title={obj.title}
        id={obj.id}
      />
    ));
  };
  render() {
    return (
      <div className='wrapper'>
        <label>Add Item</label>
        <input
          value={this.state.itemTitleValue}
          onChange={this.handleOnChange}
        />
        <button onClick={this.handleCreate}>Add</button>
        <div className='item-wrapper'>{this.insertData()}</div>
      </div>
    );
  }
}
