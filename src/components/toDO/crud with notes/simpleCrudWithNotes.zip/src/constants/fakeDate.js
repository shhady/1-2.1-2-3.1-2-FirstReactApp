export const data = [
  {
    title: 'Stylish hat',
    id: 1,
  },
  {
    title: 'Beautiful Jacket',
    id: 2,
  },
  {
    title: 'Fashionable Jeans',
    id: 3,
  },
  {
    title: 'Smart tie',
    id: 4,
  },
];
